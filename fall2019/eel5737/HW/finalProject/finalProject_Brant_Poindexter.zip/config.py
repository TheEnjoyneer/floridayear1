#Total blocks must be greater than block size
#Inode size must be less than Block size
#Min size of file name is 5


TOTAL_NO_OF_BLOCKS = 1024
BLOCK_SIZE = 512
MAX_NUM_INODES = 32
INODE_SIZE = 128
MAX_FILE_NAME_SIZE = 16
NUM_OF_SERVERS = 16
DELAY_LENGTH = 0
